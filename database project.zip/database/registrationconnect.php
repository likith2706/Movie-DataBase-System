<?php 
$fname = filter_input(INPUT_POST,'fname');
$lname = filter_input(INPUT_POST,'lname');
$uname = filter_input(INPUT_POST,'uname');
$password = filter_input(INPUT_POST,'password');
$email = filter_input(INPUT_POST,'email');
$dob = filter_input(INPUT_POST,'dob');
$gender = filter_input(INPUT_POST,'gender');
if (!empty($fname)) {
	if(!empty($lname))
	{
	$host="localhost";
	$dbusername="root";
	$dbpassword="";
	$dbname="bus";
	//create connection
	$conn=new mysqli($host,$dbusername,$dbpassword,$dbname);
	if (mysqli_connect_error()) {
		die('connection error('.mysqli_connect_errno().')'.mysqli_connect_error());
		# code...
	}
	else{
		$sql1="INSERT INTO registration(fname,lname,uname,password,email,dob,gender) values('$fname','$lname','$uname','$password','$email','$dob','$gender')"; 
		$sql2="INSERT INTO login(username,password) values('$uname','$password')";
	if ($conn->query($sql1)) {
		echo "YOUR REGISTRATION IS SUCCESSFULL";
	}
	if ($conn->query($sql2)) {
		echo "YOU CAN NOW LOGIN WITH YOUR USERNAME AND PASSWORD";
	}
	else
	{
		echo "error:".$sql."<br>".$conn->error;
	}
	$conn->close();
	}
	# code...
}
else
{
	echo "USERNAME SHOULD SHOULD BE FILLED";
	die();
}
}
else{
	echo "NAME SHOULD BE NOT BE EMPTY";
	die();
}
?>
