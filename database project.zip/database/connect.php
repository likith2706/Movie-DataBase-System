<?php 
$name = filter_input(INPUT_POST,'name');
$from_place = filter_input(INPUT_POST,'from_place');
$to_place = filter_input(INPUT_POST,'to_place');
$dot = filter_input(INPUT_POST,'dot');
$nop = filter_input(INPUT_POST,'nop');
if (!empty($name)) {
	if(!empty($from_place))
	{
	$host="localhost";
	$dbusername="root";
	$dbpassword="";
	$dbname="bus";
	//create connection
	$conn=new mysqli($host,$dbusername,$dbpassword,$dbname);
	if (mysqli_connect_error()) {
		die('connection error('.mysqli_connect_errno().')'.mysqli_connect_error());
		# code...
	}
	else{
	if ($from_place == 'chennai') {
		if ($to_place=='RED') {
			$amount=200*$nop;
			echo "AMOUNT charged will be (200 per person) ";
			echo($amount);	# code...
		}
		elseif ($to_place=='MASTER') {
			$amount=450*$nop;
			echo "AMOUNT charged will be (450 per person) ";
			echo($amount);
			# code...
		}
		elseif ($to_place=='WONDER WOMEN 1984') {
			$amount=400*$nop;
			echo "AMOUNT charged will be (400 per person) ";
			echo($amount);
			# code...
		}
		elseif ($to_place=='MONSTER HUNTER') {
			$amount=450*$nop;
			echo "AMOUNT charged will be (450 per person) ";
			echo($amount);
			# code...
		}
		elseif ($to_place=='INSPECTOR VIKRAM') {
			$amount=350*$nop;
			echo "AMOUNT charged will be (350 per person) ";
			echo($amount);
			# code...
		}
		else
		{
			echo "SERVICES ARE NOT OFFERED IN THE CITY YOU HAVE SELECTED";
		exit();
	    }
		# code...
	}
	elseif ($from_place == 'banglore') {
		if ($to_place=='RED') {
			$amount=200*$nop;
			echo "AMOUNT charged will be (200 per person) ";
			echo($amount);	# code...
		}
		elseif ($to_place=='MASTER') {
			$amount=350*$nop;
			echo "AMOUNT charged will be (350 per person) ";
			echo($amount);
			# code...
		}
		elseif ($to_place=='WONDER WOMEN 1984') {
			$amount=300*$nop;
			echo "AMOUNT charged will be (300 per person) ";
			echo($amount);
			# code...
		}
		elseif ($to_place=='MONSTER HUNTER') {
			$amount=300*$nop;
			echo "AMOUNT charged will be (300 per person) ";
			echo($amount);
			# code...
		}
		elseif ($to_place=='INSPECTOR VIKRAM') {
			$amount=350*$nop;
			echo "AMOUNT charged will be (350 per person) ";
			echo($amount);
			# code...
		}
		else{
			echo "SERVICES ARE NOT OFFERED IN THE CITY YOU HAVE SELECTED";
		exit();
	     }
		# code...
	}
	elseif ($from_place == 'mumbai') {
		if ($to_place=='RED') {
			$amount=350*$nop;
			echo "AMOUNT charged will be (300 per person) ";
			echo($amount);	# code...
		}
		elseif ($to_place=='MASTER') {
			$amount=450*$nop;
			echo "AMOUNT charged will be (450 per person) ";
			echo($amount);
			# code...
		}
		elseif ($to_place=='WONDER WOMEN 1984') {
			$amount=200*$nop;
			echo "AMOUNT charged will be (200 per person) ";
			echo($amount);
			# code...
		}
		elseif ($to_place=='MONSTER HUNTER') {
			$amount=400*$nop;
			echo "AMOUNT charged will be (400 per person) ";
			echo($amount);
			# code...
		}
		elseif ($to_place=='INSPECTOR VIKRAM') {
			$amount=350*$nop;
			echo "AMOUNT charged will be (350 per person) ";
			echo($amount);
			# code...
		}
		else
		{
			echo "SERVICES ARE NOT OFFERED IN THE CITY YOU HAVE SELECTED";
		exit();
	     }
		# code...
	}
	elseif ($from_place == 'hyderabad') {
		if ($to_place=='RED') {
			$amount=300*$nop;
			echo "AMOUNT charged will be (300 per person) ";
			echo($amount);	# code...
		}
		elseif ($to_place=='MASTER') {
			$amount=400*$nop;
			echo "AMOUNT charged will be  (400 per person) ";
			echo($amount);
			# code...
		}
		elseif ($to_place=='WONDER WOMEN 1984') {
			$amount=400*$nop;
			echo "AMOUNT charged will be (400 per person) ";
			echo($amount);
			# code...
		}
		elseif ($to_place=='MONSTER HUNTER') {
			$amount=450*$nop;
			echo "AMOUNT charged will be (450 per person) ";
			echo($amount);
			# code...
		}
		elseif ($to_place=='INSPECTOR VIKRAM') {
			$amount=350*$nop;
			echo "AMOUNT charged will be (350 per person) ";
			echo($amount);
			# code...
		}
		else{
			echo "SERVICES ARE NOT OFFERED IN THE CITY YOU HAVE SELECTED";
		exit();
	    }
				# code...
}
if (!empty($amount))
{
$sql1="INSERT INTO booking(name,from_place,to_place,dot,nop,amount) values('$name','$from_place','$to_place','$dot','$nop','$amount')"; 
	if ($conn->query($sql1)) {
		echo " Rs/-  YOUR BOOKING HAS BEEN RECORDED  ";
		echo <<<HTML
<a href="payment.html"><button type="button" class="btn btn-primary"> click here to proceed for payment</a>
HTML;
	}
}
	else
	{
		echo "error:".$sql."<br>".$conn->error;
	}
	$conn->close();
	}	# code...
}
else
{
	echo "PLACE SHOULD BE FILLED";
	die();
}
}
else{
	echo "NAME SHOULD BE NOT BE EMPTY";
	die();
}
?>
