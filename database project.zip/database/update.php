<?php
$conn=mysqli_connect("localhost","root","","bus");
	if($conn-> connect_error) {
		die("connection failed:".$conn->connection_error);
	}
	$name=$_GET['a'];
	$s ="SELECT name,from_place,to_place,dot,nop from booking where name ='$name'";
	$result=$conn->query($s);	
			?>
			<form action="" method="post">
				<link rel="stylesheet"  href="styler.css">
<table border=1>
<?php while ($row=$result->fetch_assoc()) {
			?>
			<tr><td><input type="hidden" name="name" value="<?php echo $row["name"];?>"></td>
				<td><input type="text" name="from_place" value="<?php echo $row["from_place"];?>"></td>
				<td><input type="text" name="to_place" value="<?php echo $row["to_place"];?>"></td>
				<td><input type="text" name="dot" value="<?php echo $row["dot"];?>"></td>
				<td><input type="text" name="nop" value="<?php echo $row["nop"];?>"></td>
				<td><input type="submit" name="s" value="change now"></td>
			</tr>
<?php }
?>
</table>
<?php
if (isset($_POST['s']))
 {
$nm = filter_input(INPUT_POST,'name');
$f = filter_input(INPUT_POST,'from_place');
$t = filter_input(INPUT_POST,'to_place');
$d = filter_input(INPUT_POST,'dot');
$n = filter_input(INPUT_POST,'nop');
$conn=mysqli_connect("localhost","root","","bus");
if (mysqli_connect_error()) {
		die('connection error('.mysqli_connect_errno().')'.mysqli_connect_error());
		# code...
	}
	else{
		$sql="UPDATE booking set from_place='$f',to_place='$t',dot='$d',nop='$n' WHERE name ='$nm'"; 
	if ($conn->query($sql)) {
		echo "YOUR EDIT IS DONE SUCCESSFULLY";
		        echo <<<HTML
<a href="homepage.html"><button type="button" class="btn btn-primary">click here</a>
HTML;
	}
	else
	{
		echo "error:".$sql."<br>".$conn->error;
	}
}
}
	$conn->close();
?>
