<?php 
$BID = filter_input(INPUT_POST,'BID');
$currentdate = new DateTime();
if (!empty($BID)) {
  $host="localhost";
  $dbusername="root";
  $dbpassword="";
  $dbname="bus";
  $con = mysqli_connect("localhost","root","","bus");
  //create connection
  $conn=new mysqli($host,$dbusername,$dbpassword,$dbname);
  $s ="SELECT name,from_place,to_place,dot,nop from booking";
  if (mysqli_connect_error()) {
    die('connection error('.mysqli_connect_errno().')'.mysqli_connect_error());
    # code...
  }
  else
    {
      if(isset($_REQUEST["b1"]))
{
      $BID=$_REQUEST["BID"];
      $query=mysqli_query($con,"select * from booking where booking_ID='$BID'");
      $rowcount=mysqli_num_rows($query);
      if ($rowcount==true) {
            echo "BOOKING ID $BID  FOUND ";
          
    $sql1="DELETE FROM booking where(booking_ID) in('$BID')"; 
    $sql2="INSERT INTO cancellation(BID) values('$BID')";
  if ($conn->query($sql1)) {
    echo "YOUR BOOKING HAS BEEN CANCELLED ";

  }
  if ($conn->query($sql2)) {
    echo"YOUR AMOUNT WILL BE REFUNDED BASED ON THE MEMBERSHIP YOU HAVE OPTED";
  }
  else
  {
    echo "error:".$sql."<br>".$conn->error;
    echo "BOOKING ID NOT FOUND";
  }
  $conn->close();
  }
  else{
    echo "BOOKING ID NOT FOUND";
  }
}
else{
    echo "BOOKING ID NOT FOUND";
  }
  }
}
  # code...
else
{
  echo "BOOKING ID SHOULD BE FILLED";
  die();
}
?>