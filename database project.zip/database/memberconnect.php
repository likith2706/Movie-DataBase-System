<?php 
$Mname = filter_input(INPUT_POST,'Mname');
$term = filter_input(INPUT_POST,'term');
$type = filter_input(INPUT_POST,'type');
if (!empty($Mname)) {
	if(!empty($term))
	{
	$host="localhost";
	$dbusername="root";
	$dbpassword="";
	$dbname="bus";
	//create connection
	$conn=new mysqli($host,$dbusername,$dbpassword,$dbname);
	if (mysqli_connect_error()) {
		die('connection error('.mysqli_connect_errno().')'.mysqli_connect_error());
		# code...
	}
	else{
		$sql="INSERT INTO members(Mname,term,type) values('$Mname','$term','$type')"; 
	if ($conn->query($sql)) {
		echo "YOUR MEMBERSHIP REQUEST IS ACCPETED AND WILL BE PROCESSED ";
		echo <<<HTML
<a href="homepage.html"><button type="button" class="btn btn-primary"> click here to proceed for homepage</a>
HTML;
	}
	else
	{
		echo "error:".$sql."<br>".$conn->error;
	}
	$conn->close();
	}
	# code...
}
else
{
	echo "TERM SHOULD BE FILLED";
	die();
}
}
else{
	echo "NAME SHOULD BE NOT BE EMPTY";
	die();
}
?>