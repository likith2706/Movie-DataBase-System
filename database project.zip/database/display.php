<!DOCTYPE html>
<html>
<head>
	<title>DISPLAY</title>
	<style type="text/css">
		html
		{
	background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)),url(img/background.jpg);
	background-size: cover;
	background-position: center;
		}
		h3
		{
			font-size: 50px;
				text-align: center;
	color: #efefef!important;
	padding-bottom: 10px;
		}
		table{
			border-collapse: collapse;
			width: 100%;
			color: #d96459;
			font-family: monospace;
			font-size: 25px;
			text-align: center;
		}
		th{
			color: white;
		}
	</style>
</head>
<body>
	<h3>BOOKING DETAILS</h3>
<table>
	<tr>
		<th>NAME</th>
		<th>CITY</th>
		<th>MOVIE</th>
		<th>DATE</th>
		<th>NUMBER OF SEATS</th>
		<th>BOOKING ID</th>
		<th>UPDATE</th>
	</tr>
	<?php
	$conn=mysqli_connect("localhost","root","","bus");
	if($conn-> connect_error) {
		die("connection failed:".$conn->connection_error);
	}
	$sql="SELECT name,from_place,to_place,dot,nop,booking_ID from booking";
	$result=$conn->query($sql);
	if($result->num_rows>0){
		while ($row=$result->fetch_assoc()) {
			?>
			<tr>
				<td><?php echo $row["name"];?></td>
				<td><?php echo $row["from_place"];?></td>
				<td><?php echo $row["to_place"];?></td>
				<td><?php echo $row["dot"];?></td>
				<td><?php echo $row["nop"];?></td>
				<td><?php echo $row["booking_ID"];?></td>
				<td><a href="update.php?a=<?php echo $row['name'];?>" >CHANGE</a></td>
			</tr>
			<?php
		}
		echo "</table>";
	}
	else
	{
		echo "0 result";
	}
	$conn->close();
	?>
	<button type="button" class="btn btn-primary"><a href="display.php">GO BACK TO HOMEPAGE</a></button>
</table>
</body>
</html>