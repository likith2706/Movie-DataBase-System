<?php $linkname= "homepage";
$con = mysqli_connect("localhost","root","","bus");
if(isset($_REQUEST["button"]))
{
      $user=$_REQUEST["user"];
      $pass=$_REQUEST["pass"];
      $query=mysqli_query($con,"select * from login where username='$user' && password='$pass'");
      $rowcount=mysqli_num_rows($query);
      if ($rowcount==true) {
            echo "LOGIN SUCCESS";
          //echo  '<a href=\\"localhost/database/homepage.html">click here</a>:';
          echo <<<HTML
<a href="homepage.html"><button type="button" class="btn btn-primary">click here</a>
HTML;

      # code...
      }
      else
      {
            echo "ENTER CORRECT USERNAME AND PASSWORD";
      }
}
?>
<html>
<head>
	<title>LOGIN PAGE</title>
	<link rel="stylesheet" type="text/css" href="stylel.css">
      </head>
<body>
      	<div class="loginbox">
                  <form method="POST">
      		<img src="img/avatar.png" class="avatar">
      			<h1>LOGIN IN</h1>
                               <p>USERNAME
                               <input type="text" name="user" id="user"placeholder="Enter username"></p>
                               <p>PASSWORD
                               <input type="Password" name="pass" id="pass" placeholder="Enter Password"></p>
                             <p> <input type="submit" name="button" value="login"></p>
                             <br><br><a type="text" href="registration.html">New user ? sign up here</a>

</form>                 
</div>		
</body>
</html>