<?php 
$name = filter_input(INPUT_POST,'name');
$card_no = filter_input(INPUT_POST,'card_no');
if (!empty($name)) {
	if(!empty($card_no))
	{
	$host="localhost";
	$dbusername="root";
	$dbpassword="";
	$dbname="bus";
	//create connection
	$conn= new mysqli($host,$dbusername,$dbpassword,$dbname);
	if (mysqli_connect_error()) {
		die('connection error('.mysqli_connect_errno().')'.mysqli_connect_error());
		# code...
	}
	else{
		$sql="INSERT INTO payment(name,card_no) values('$name','$card_no')"; 
	if ($conn->query($sql)) {
		echo "PAYMENT IS DONE SUCCESSFULLY";
		$receiver = "From:likith.m27@gmail.com";
$subject = "Email Test via PHP using Localhost";
$body = "Hi, there...This is a test email send from Localhost.";
$sender = "From:likith.m27@gmail.com";

if(mail($receiver, $subject, $body, $sender)){
    echo "Email sent successfully to $receiver";
}else{
    echo "Sorry, failed while sending mail!";
}

	}
	else
	{
		echo "error:".$sql."<br>".$conn->error;
	}
	$conn->close();
	}
	# code...
}
else
{
	echo "CARD NUMBER SHOULD BE FILLED";
	die();
}
}
else{
	echo "OWNER NAME SHOULD BE FILLED";
	die();
}
?>