<?php 
$amount = filter_input(INPUT_POST,'amount');
$name = filter_input(INPUT_POST,'name');
$card_no = filter_input(INPUT_POST,'card_no');
if (!empty($amount)) {
	if(!empty($card_no))
	{
	$host="localhost";
	$dbusername="root";
	$dbpassword="";
	$dbname="bus";
	//create connection
	$conn=new mysqli($host,$dbusername,$dbpassword,$dbname);
	if (mysqli_connect_error()) {
		die('connection error('.mysqli_connect_errno().')'.mysqli_connect_error());
		# code...
	}
	else{
		$sql="INSERT INTO payment(amount,name,card_no) values('$amount','$name','$card_no')"; 
	if ($conn->query($sql)) {
		echo "PAYMENT IS DONE SUCCESSFULLY";
	}
	else
	{
		echo "error:".$sql."<br>".$conn->error;
	}
	$conn->close();
	}
	# code...
}
else
{
	echo "AMOUNT SHOULD BE FILLED";
	die();
}
}
else{
	echo "CARD NUMBER IS IN VALID";
	die();
}
?>