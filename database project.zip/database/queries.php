<!DOCTYPE html>
<html>
<head>
	<title>QUERY</title>
	<style type="text/css">
		html
		{
	background-image:url(img/queryb.jpg);
	background-size: cover;
	background-position: center;
		}
		h3
		{
			font-size: 50px;
				text-align: center;
	color: #000!important;
	padding-bottom: 10px;
		}
		.myform{
			border-collapse: collapse;
			width: 100%;
			color: #fff;
			font-family: monospace;
			font-size: 25px;
			text-align: center;
		}

		th{
			color: white;
		}
		#php
{
	padding-top: 50px;
	padding-bottom: 50px;
	color: #555; 
}
#php .btn
{
	margin-top: 20px;
	margin-bottom: 30px;
}
.php-content
{
	padding-top: 20px;
}
	</style>
</head>
<body background-color="#000">
	</tr>
	<div id="php">
		<form class="myform" action="" method="post">
			<label style="color: white"><b><h3>SUBMIT YOUR QUERY : </b></h3></label><br>
			<input name="fname" type="text" class="input" placeholder="ENTER YOUR QUERY" required=""/><br>
			<input name="submit_btn" type="submit" id="signup_btn" value="submit"/><br>
			<h3>THE OUTPUT IS : </h3>
		</form>
	</div>
	<?php
	$host="localhost";
$dbuser="root";
$pass="";
$dbname="bus";
$con=mysqli_connect($host,$dbuser,$pass,$dbname);
if(mysqli_connect_errno())
{
	die("connection failed!".mysqli_connect_error());
}
	if(isset($_POST['submit_btn']))
	{
		$fname = $_POST['fname'];
		$sql="$fname";
		$result=mysqli_query($con,$sql);
		while ($arr=mysqli_fetch_row($result)) {
			//$str=implode(',',$arr);
			echo "<br>&nbsp;";
			echo implode(' &nbsp',$arr);
			# code...
		}
	}
	$con->close();
	?>
	<br><br><button type="button" class="btn btn-primary bus"><a href="homepage.html">GO BACK TO HOMEPAGE</a></button>
</body>
</html>